import React, { createContext, useState, useEffect } from "react";
import { useRouter } from "next/router";
import {
  login as loginService,
  logout as logoutService,
} from "../services/authService";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("user_id");
    if (token && userId) {
      setUser({ user_id: userId });
    }
    setLoading(false);
  }, []);

  const loginUser = async (email, password) => {
    try {
      const { access_token, user_id } = await loginService(email, password);
      setUser({ user_id });
      localStorage.setItem("token", access_token);
      localStorage.setItem("user_id", user_id);
      router.push("/");
    } catch (error) {
      throw new Error(error.message);
    }
  };

  const logoutUser = () => {
    logoutService();
    setUser(null);
    router.push("/sign-in");
  };

  return (
    <AuthContext.Provider value={{ user, loginUser, logoutUser, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
